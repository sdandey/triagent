"""Chainlit container for session sandboxes."""
