"""System prompts and CLAUDE.md files for Triagent."""

from triagent.prompts.system import get_system_prompt

__all__ = ["get_system_prompt"]
