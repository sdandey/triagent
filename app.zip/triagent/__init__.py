"""Triagent - Claude-powered CLI for Azure DevOps automation."""

from importlib.metadata import version

__version__ = version("triagent")
__author__ = "Santosh Dandey"
