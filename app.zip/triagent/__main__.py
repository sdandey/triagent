"""Entry point for python -m triagent."""

from triagent.cli import main

if __name__ == "__main__":
    main()
